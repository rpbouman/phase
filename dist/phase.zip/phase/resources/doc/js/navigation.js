(function(){

var location = document.location.href;
var path = location.split("/");


})();