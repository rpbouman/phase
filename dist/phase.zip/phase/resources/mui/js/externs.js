var muiCssDir;
var muiImgDir;
function getComputedStyle(){};