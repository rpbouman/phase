var MondrianModelValidator;

(function(){

var name = {
  required: true;
},
description = {
  required: true;
},
measuresCaption = {
  required: true;
}
;

var Annotation = {
  attributes: [name],
  children: "";
}

var Annotations = {
  required: false,
  children: [[Annotation]]
};

var Parameter = {
  required: false,
};

var Schema = {
  attributes: {
    name: {
      required: true
    },
    description: null,
    measuresCaption: null,
    defaultRole: null
  },
  children: [
    Annotations,[Parameter],(Dimension)*,(Cube)*,(VirtualCube)*,(NamedSet)*,(Role)*,(UserDefinedFunction)*)
  ]
};

(MondrianModelValidator = function(conf){
}).prototype = {
  ERROR: "error",
  WARNING: "warning",
  INFO: "info",
  result: function(type, message) {
    this.validationResults.push({
      type: type,
      message: message
    });
  },
  error: function(message) {
    this.result(MondrianModelValidator.ERROR, message);
  },
  warning: function(message) {
    this.result(MondrianModelValidator.WARNING, message);
  },
  info: function(message) {
    this.result(MondrianModelValidator.INFO, message);
  },
  validate: function(conf){
    this.conf = conf;
    var action = function(){
      if (this.conf.callback){
        this.conf.callback.call(this.conf.scope, validationResults);
      }
    };
    this.validationResults = [];
    var model = conf.model;
    if (!model) {
      this.error("No model specified");
      action.call(this);
    }
    else {
      this.validateModelDocument();
      if (conf.pedisCache) {
        this.validateDatabaseBindings(action);
      }
      else {
        this.info("No PedisCache configured, skipping database bindings validation");
        action.call(this);
      }
    }
  },
  validateModelDocument: function(){
  },
  validateDatabaseBindings: function(action){
  }
};

})();